#! /usr/bin/bash

pydos -p '1' -p '2' -p '3' -p '4' -p '5' -p '6' -y 0 3 -x -5 1 --notot --tofile dos.dat -o dos.png 
